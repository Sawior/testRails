class DashboardController < ApplicationController
end
